# 게시판 프로젝트

⚙ 현재 서비스 중인 URL: <https://todo-app-387113.du.r.appspot.com/>

📋 프로젝트 기간: 2023.05.08 ~ 2023.08.08

<h3> My Tech Stack 📚</h3>

![HTML5](https://img.shields.io/badge/-HTML5-F05032?style=for-the-badge&logo=html5&logoColor=ffffff)
![CSS3](https://img.shields.io/badge/-CSS3-007ACC?style=for-the-badge&logo=css3)
![JavaScript](https://img.shields.io/badge/-JavaScript-%23F7DF1C?style=for-the-badge&logo=javascript&logoColor=000000&labelColor=%23F7DF1C&color=%23FFCE5A)
![React](https://img.shields.io/badge/-React-222222?style=for-the-badge&logo=react)
![BootStrap](https://img.shields.io/badge/-BootStrap-7952B3?style=for-the-badge&logo=bootstrap&logoColor=ffffff)
![Git](https://img.shields.io/badge/-Git-F05032?style=for-the-badge&logo=git&logoColor=ffffff)

<hr/>

# 주요 기능

<!-- <img src="/path/to/img.jpg" width="450px" height="300px" title="px(픽셀) 크기 설정" alt="RubberDuck"></img><br/>
<img src="/path/to/img.jpg" width="40%" height="30%" title="px(픽셀) 크기 설정" alt="RubberDuck"></img> -->

<!--
이미지로 설명(GIF, img)

- 회원 가입

- 보안 강화를 위해 사용자의 비밀번호를 bcrypt 알고리즘을 활용하여 안전하게 암호화한 후 데이터베이스에 저장

- 게시물 작성/수정/삭제

- 댓글 작성/삭제

- 게시물 pagination

- MongoDB의 Search Index를 사용해 게시물 제목 검색

- 관리자가 사용자의 게시물 및 댓글을 관리 -->
